"""
Module used to automatically submit batches to Weaviate.
"""

__all__ = ["WCS"]

from .crud_wcs import WCS
