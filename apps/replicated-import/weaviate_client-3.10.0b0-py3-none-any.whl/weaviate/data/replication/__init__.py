"""
Module for managing and facilitating class replication.
"""

__all__ = ["ConsistencyLevel"]

from .replication import ConsistencyLevel
