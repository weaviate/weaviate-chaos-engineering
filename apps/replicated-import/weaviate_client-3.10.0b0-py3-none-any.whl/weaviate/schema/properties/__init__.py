"""
Module used to manipulate schema properties.
"""

__all__ = ["Property"]

from .crud_properties import Property
