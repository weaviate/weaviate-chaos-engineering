"""
Weaviate-Python-Client version.
"""

__version__ = "3.10.0b0"
